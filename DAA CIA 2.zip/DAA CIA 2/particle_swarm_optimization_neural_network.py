#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pyswarms as ps
import tensorflow as tf
from pyswarms.utils.functions import single_obj as fx
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

iris = load_iris()
X = iris.data
y = iris.target

le = LabelEncoder()
y = le.fit_transform(y)
y = tf.keras.utils.to_categorical(y)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

def create_model(params):
    model = tf.keras.models.Sequential()
    model.add(tf.keras.layers.Dense(params[0], input_dim=4, activation='relu'))
    model.add(tf.keras.layers.Dense(params[1], activation='relu'))
    model.add(tf.keras.layers.Dense(3, activation='softmax'))
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

def fitness_function(params, X_train, y_train):
    model = create_model(params)
    model.fit(X_train, y_train, epochs=10, verbose=0)
    loss, acc = model.evaluate(X_train, y_train, verbose=0)
    return -acc

bounds = (slice(2, 50), slice(2, 50))

options = {'c1': 0.5, 'c2': 0.3, 'w': 0.9}
optimizer = ps.single.GlobalBestPSO(n_particles=10, dimensions=2, bounds=bounds, options=options)
best_cost, best_pos = optimizer.optimize(lambda x: fitness_function(x, X_train, y_train), iters=100)

model = create_model(best_pos)
model.fit(X_train, y_train, epochs=10, verbose=0)
loss, acc = model.evaluate(X_test, y_test, verbose=0)
print('Test accuracy:', acc)


# In[ ]:




