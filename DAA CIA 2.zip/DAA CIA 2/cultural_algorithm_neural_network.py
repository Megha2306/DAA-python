#!/usr/bin/env python
# coding: utf-8

# In[1]:


import tensorflow as tf
import numpy as np
import random
from sklearn.datasets import load_boston


boston = load_boston()
data = boston.data
targets = boston.target

data_mean = np.mean(data, axis=0)
data_std = np.std(data, axis=0)
data = (data - data_mean) / data_std

def fitness_function(x, y):
    return -np.mean((np.dot(data, x) + y - targets) ** 2)

population_size = 50
num_generations = 100
mutation_rate = 0.1
knowledge_pool_size = 10

population = np.random.uniform(low=-1, high=1, size=(population_size, data.shape[1]))
knowledge_pool = []

input_dim = 10
hidden_dim = 32
output_dim = data.shape[1]
learning_rate = 0.01

inputs = tf.placeholder(tf.float32, shape=[None, input_dim, data.shape[1]])
targets = tf.placeholder(tf.float32, shape=[None, output_dim])

hidden_layer = tf.layers.dense(inputs, hidden_dim, activation=tf.nn.relu)
output_layer = tf.layers.dense(hidden_layer, output_dim)

loss = tf.reduce_mean(tf.square(output_layer - targets))
optimizer = tf.train.AdamOptimizer(learning_rate).minimize(loss)

sess = tf.Session()
sess.run(tf.global_variables_initializer())

for i in range(num_generations):
   
    fitness_values = [fitness_function(x, y) for x, y in population]

    best_indices = np.argsort(fitness_values)[-knowledge_pool_size:]
    knowledge_pool.extend(population[best_indices])

    knowledge_pool = sorted(knowledge_pool, key=lambda x: fitness_function(x, 0))

    new_population = []
    for j in range(population_size):
       
        if random.random() < mutation_rate:
            
            parent = random.choice(population)
            mutation = np.random.normal(loc=0, scale=0.1, size=data.shape[1])
            child = parent + mutation
        else:
            
            nn_input = np.array([knowledge_pool[random.randint(0, len(knowledge_pool)-1)] for _ in range(10)])
            nn_output = sess.run(output_layer, feed_dict={inputs: np.expand_dims(nn_input, axis=0)})
            child = nn_output[0]

        new_population.append(child)

    population = np.array(new_population)


# In[ ]:




