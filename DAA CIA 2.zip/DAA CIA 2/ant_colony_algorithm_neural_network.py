#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import tensorflow as tf
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler


iris = load_iris()

scaler = StandardScaler()
X = scaler.fit_transform(iris.data)

num_ants = 10
num_iterations = 100
num_nodes = X.shape[0]
num_features = X.shape[1]
num_classes = len(np.unique(iris.target))
alpha = 1
beta = 2
evaporation_rate = 0.5
pheromone = np.ones((num_nodes, num_nodes))

model = tf.keras.Sequential([
    tf.keras.layers.Dense(10, input_dim=num_features, activation='relu'),
    tf.keras.layers.Dense(num_nodes, activation='softmax')
])
model.compile(loss='categorical_crossentropy', optimizer=tf.keras.optimizers.Adam())


y = tf.keras.utils.to_categorical(iris.target, num_classes=num_classes)


for i in range(num_iterations):
    for ant in range(num_ants):
        
        current_node = np.random.randint(num_nodes)
        visited_nodes = [current_node]
        for j in range(num_nodes-1):
            
            probabilities = pheromone[current_node,:]**alpha *                 (1.0 / (np.sum((pheromone[current_node,:]**alpha) *                 (1.0 / X[current_node,:]**beta))))
            probabilities[visited_nodes] = 0
            probabilities /= np.sum(probabilities)
            
            next_node = np.random.choice(num_nodes, p=probabilities)
            visited_nodes.append(next_node)
            current_node = next_node
        
        distances = np.linalg.norm(X[visited_nodes[:-1],:] - X[visited_nodes[1:],:], axis=1)
        pheromone[visited_nodes[:-1], visited_nodes[1:]] = (1-evaporation_rate) * pheromone[visited_nodes[:-1], visited_nodes[1:]] + evaporation_rate * (1 / distances)
        
        X_train = X[visited_nodes,:]
        y_train = pheromone[visited_nodes[:-1], visited_nodes[1:]].flatten()
        y_train /= np.sum(y_train)
        model.train_on_batch(X_train, y_train)
    
    y_pred = model.predict(X)
    y_pred = y_pred / np.sum(y_pred, axis=1)[:,np.newaxis]
    pheromone = (1-evaporation_rate) * pheromone + evaporation_rate * y_pred

y_pred = model.predict(X)
y_pred = np.argmax(y_pred, axis=1)
accuracy = np.mean(y_pred == iris.target)
print('Accuracy:', accuracy)


probabilities = pheromone[0,:]**alpha * (1.0 / (np.sum((pheromone[0,:]**alpha) * (1.0 / X[0,:]**beta))))
probabilities /= np.sum(probabilities)
current_node = 0
visited_nodes = [0]
for j in range(num_nodes-1):
    next_node = np.random


# In[ ]:




