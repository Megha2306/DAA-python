#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import tensorflow as tf

def fitness(chromosome, dataset):
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dense(10, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    model.fit(dataset[0], dataset[1], epochs=10, verbose=0)
    return model.evaluate(chromosome[tf.newaxis,:], dataset[1])[1]

mnist = tf.keras.datasets.mnist.load_data()
x_train = mnist[0][0]
y_train = tf.keras.utils.to_categorical(mnist[0][1])

population_size = 10
chromosome_length = x_train.shape[1]
population = tf.random.uniform([population_size, chromosome_length], minval=0, maxval=1)

num_generations = 10
crossover_rate = 0.5
mutation_rate = 0.1

for i in range(num_generations):
    
    fitness_values = [fitness(chromosome, (x_train, y_train)) for chromosome in population]
    
    parent_indices = tf.random.categorical(tf.math.log(tf.ones([population_size, 1])), population_size // 2)
    parents = tf.gather(population, parent_indices, batch_dims=0)
    
    crossover_mask = tf.random.uniform([population_size // 2, chromosome_length], minval=0, maxval=1) < crossover_rate
    offspring = tf.where(crossover_mask, parents[:, ::-1], parents)
    
    mutation_mask = tf.random.uniform([population_size, chromosome_length], minval=0, maxval=1) < mutation_rate
    mutation_values = tf.random.uniform([population_size, chromosome_length], minval=0, maxval=1)
    offspring = tf.where(mutation_mask, mutation_values, offspring)
    
    next_generation = tf.concat([population, offspring], axis=0)
    
    next_generation_fitness = [fitness(chromosome, (x_train, y_train)) for chromosome in next_generation]
    top_indices = tf.argsort(next_generation_fitness)[-population_size:]
    population = tf.gather(next_generation, top_indices, batch_dims=0)


best_individual = population[tf.argmax([fitness(chromosome, (x_train, y_train)) for chromosome in population])]
best_fitness = fitness(best_individual, (x_train, y_train))
print('Best individual:', best_individual.numpy())
print('Best fitness:', best_fitness)


# In[ ]:




